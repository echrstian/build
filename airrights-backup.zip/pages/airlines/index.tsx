import { useState, useEffect } from 'react';
import Head from 'next/head';
import Layout from '../../components/Layout';
import LoadingSpinner from '../../components/LoadingSpinner';
import { api } from '../../utils/supabaseClient';
import { Airline } from '../../utils/types';
import Link from 'next/link';

export default function AirlinesListPage() {
  const [airlines, setAirlines] = useState<Airline[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    async function fetchAirlines() {
      try {
        setLoading(true);
        const fetchedAirlines = await api.getAllAirlines();
        
        // Sort alphabetically by name
        const sortedAirlines = [...fetchedAirlines].sort((a, b) => 
          a.name.localeCompare(b.name)
        );
        
        setAirlines(sortedAirlines);
      } catch (err) {
        console.error('Error fetching airlines:', err);
        setError(err instanceof Error ? err.message : 'Failed to load airlines');
      } finally {
        setLoading(false);
      }
    }

    fetchAirlines();
  }, []);

  return (
    <Layout>
      <Head>
        <title>All Airlines - AirRights Canada</title>
        <meta 
          name="description" 
          content="Browse passenger rights and compensation policies for all major Canadian airlines." 
        />
      </Head>

      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <Link href="/" className="text-blue-500 hover:underline mb-4 inline-block">
            &larr; Back to Home
          </Link>
          <h1 className="text-3xl md:text-4xl font-bold mt-4 mb-2">All Airlines</h1>
          <p className="text-gray-600 mb-8">
            Select an airline to view their passenger rights and compensation policies.
          </p>
        </div>

        {loading ? (
          <div className="flex justify-center py-12">
            <LoadingSpinner />
          </div>
        ) : error ? (
          <div className="bg-red-50 border border-red-200 text-red-800 p-4 rounded-md">
            <p className="font-medium">Error loading airlines</p>
            <p>{error}</p>
          </div>
        ) : (
          <>
            {airlines.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {airlines.map((airline) => (
                  <Link href={`/airlines/${airline.slug}`} key={airline.id}>
                    <div className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow border border-gray-200">
                      <div className="flex items-center mb-4">
                        <h2 className="text-xl font-semibold text-gray-800">{airline.name}</h2>
                        {airline.iata_code && (
                          <span className="ml-2 bg-gray-100 text-gray-800 px-2 py-1 rounded text-sm">
                            {airline.iata_code}
                          </span>
                        )}
                      </div>
                      {airline.description && (
                        <p className="text-gray-600 text-sm line-clamp-3">{airline.description}</p>
                      )}
                      <div className="mt-4 text-blue-500 hover:underline flex items-center">
                        <span>View passenger rights</span>
                        <svg className="w-4 h-4 ml-1" viewBox="0 0 20 20" fill="currentColor">
                          <path fillRule="evenodd" d="M10.293 5.293a1 1 0 011.414 0l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414-1.414L12.586 11H5a1 1 0 110-2h7.586l-2.293-2.293a1 1 0 010-1.414z" clipRule="evenodd" />
                        </svg>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            ) : (
              <div className="text-center py-12 bg-gray-50 rounded-lg border border-gray-200">
                <p className="text-gray-600">No airlines found. Please check back later.</p>
              </div>
            )}
          </>
        )}
      </div>
    </Layout>
  );
}