import { useRouter } from 'next/router';
import { useEffect, useState } from 'react';
import Head from 'next/head';
import Layout from '../../components/Layout';
import ScenarioTabs from '../../components/ScenarioTabs';
import LoadingSpinner from '../../components/LoadingSpinner';
import AirlineSelector from '../../components/AirlineSelector';
import { api } from '../../utils/supabaseClient';
import { Airline, Right, ScenarioType } from '../../utils/types';
import Link from 'next/link';

export default function AirlinePage() {
  const router = useRouter();
  const { airline: airlineSlug, scenario: initialScenario } = router.query;
  
  const [airline, setAirline] = useState<Airline | null>(null);
  const [rights, setRights] = useState<Right[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [activeScenario, setActiveScenario] = useState<ScenarioType | null>(null);

  useEffect(() => {
    if (!airlineSlug) return;

    const fetchAirlineAndRights = async () => {
      try {
        setLoading(true);
        
        // Fetch airline data
        const airlineData = await api.getAirlineBySlug(airlineSlug as string);
        
        if (!airlineData) throw new Error('Airline not found');
        
        setAirline(airlineData);
        
        // Fetch rights data for this airline
        const airlineId = typeof airlineData.id === 'string' 
          ? parseInt(airlineData.id, 10) 
          : airlineData.id;
        
        const rightsData = await api.getRightsByAirline(airlineId);
        
        setRights(rightsData || []);
        
        // Set initial scenario from URL or default to 'delay'
        if (initialScenario && typeof initialScenario === 'string') {
          setActiveScenario(initialScenario as ScenarioType);
        } else {
          setActiveScenario('delay');
        }
        
      } catch (err) {
        console.error('Error:', err);
        setError(err instanceof Error ? err.message : 'An error occurred');
      } finally {
        setLoading(false);
      }
    };
    
    fetchAirlineAndRights();
  }, [airlineSlug, initialScenario]);

  // Update URL when scenario changes
  useEffect(() => {
    if (activeScenario && airline) {
      router.push(`/airlines/${airlineSlug}?scenario=${activeScenario}`, undefined, { shallow: true });
    }
  }, [activeScenario, airline, airlineSlug, router]);

  if (loading) {
    return (
      <Layout>
        <div className="flex justify-center items-center min-h-screen">
          <LoadingSpinner />
        </div>
      </Layout>
    );
  }

  if (error) {
    return (
      <Layout>
        <div className="container mx-auto px-4 py-12 text-center">
          <h1 className="text-2xl font-bold text-red-500 mb-4">Error</h1>
          <p className="mb-4">{error}</p>
          <Link href="/" className="bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600">
            Return to Home
          </Link>
        </div>
      </Layout>
    );
  }

  if (!airline) {
    return (
      <Layout>
        <div className="container mx-auto px-4 py-12 text-center">
          <h1 className="text-2xl font-bold mb-4">Airline Not Found</h1>
          <p className="mb-4">We couldn't find information for the requested airline.</p>
          <Link href="/" className="bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600">
            Return to Home
          </Link>
        </div>
      </Layout>
    );
  }

  const filteredRights = activeScenario 
    ? rights.filter(right => right.scenario_type === activeScenario) 
    : rights;

  return (
    <Layout>
      <Head>
        <title>{airline.name} - Passenger Rights | AirRights Canada</title>
        <meta 
          name="description" 
          content={`Learn about your passenger rights when flying with ${airline.name} under Canada's Air Passenger Protection Regulations.`} 
        />
      </Head>
      
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <Link href="/" className="text-blue-500 hover:underline mb-4 inline-block">
            &larr; Back to Home
          </Link>
          
          {/* Airline selector */}
          <div className="mb-6 max-w-md">
            <AirlineSelector 
              onSelect={(selectedAirline) => {
                if (selectedAirline.id !== airline.id) {
                  router.push(`/airlines/${selectedAirline.slug}${activeScenario ? `?scenario=${activeScenario}` : ''}`);
                }
              }} 
              selectedAirlineId={airline.id.toString()}
            />
          </div>
          
          <div className="flex items-center mb-2">
            <h1 className="text-3xl md:text-4xl font-bold">{airline.name}</h1>
            {airline.iata_code && (
              <span className="ml-2 bg-gray-100 text-gray-800 px-2 py-1 rounded text-sm">
                {airline.iata_code}
              </span>
            )}
          </div>
          <p className="text-gray-600 mb-6">{airline.description}</p>
        </div>
        
        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <ScenarioTabs 
            activeScenario={activeScenario || 'delay'} 
            onChange={(scenario) => setActiveScenario(scenario)}
          />
          
          <div className="mt-6">
            {filteredRights.length > 0 ? (
              <div className="space-y-6">
                {filteredRights.map((right) => (
                  <div key={right.id} className="bg-gray-50 p-4 rounded-lg border border-gray-200">
                    <h3 className="text-xl font-semibold mb-2">{getScenarioTitle(right.scenario_type)}</h3>
                    
                    {right.compensation_amount && (
                      <div className="mb-4">
                        <h4 className="text-lg font-medium mb-1">Compensation:</h4>
                        <p className="text-gray-700">{right.compensation_amount}</p>
                      </div>
                    )}
                    
                    {right.eligibility_criteria && (
                      <div className="mb-4">
                        <h4 className="text-lg font-medium mb-1">Eligibility Criteria:</h4>
                        <p className="text-gray-700">{right.eligibility_criteria}</p>
                      </div>
                    )}
                    
                    {right.legal_reference && (
                      <div className="mt-4 text-sm text-gray-500">
                        <h4 className="font-medium">Legal Reference:</h4>
                        <p>{right.legal_reference}</p>
                      </div>
                    )}
                    
                    <div className="mt-6 flex flex-wrap gap-2">
                      <a 
                        href="https://rppa-appr.ca/eng/air-passenger-protection-regulations" 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="text-blue-500 hover:underline text-sm flex items-center"
                      >
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                          <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path>
                          <polyline points="15 3 21 3 21 9"></polyline>
                          <line x1="10" y1="14" x2="21" y2="3"></line>
                        </svg>
                        View CTA Guidelines
                      </a>
                      
                      <a 
                        href="https://rppa-appr.ca/eng/file-complaint-about-air-carrier" 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="text-blue-500 hover:underline text-sm flex items-center"
                      >
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                          <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                          <polyline points="14 2 14 8 20 8"></polyline>
                          <line x1="16" y1="13" x2="8" y2="13"></line>
                          <line x1="16" y1="17" x2="8" y2="17"></line>
                          <polyline points="10 9 9 9 8 9"></polyline>
                        </svg>
                        File a Complaint
                      </a>
                      
                      <button 
                        onClick={() => {
                          const url = window.location.href;
                          navigator.clipboard.writeText(url);
                          alert('Link copied to clipboard!');
                        }}
                        className="text-blue-500 hover:underline text-sm flex items-center"
                      >
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                          <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
                          <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
                        </svg>
                        Copy Link
                      </button>
                      
                      <a 
                        href={`mailto:?subject=Passenger Rights for ${airline.name} - ${getScenarioTitle(right.scenario_type)}&body=I thought you might find this information about passenger rights helpful: ${window.location.href}`} 
                        className="text-blue-500 hover:underline text-sm flex items-center"
                      >
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                          <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path>
                          <polyline points="22,6 12,13 2,6"></polyline>
                        </svg>
                        Share via Email
                      </a>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <p className="text-gray-600">No specific information available for this scenario.</p>
                <p className="mt-2">
                  <a 
                    href="https://rppa-appr.ca/eng/air-passenger-protection-regulations" 
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-blue-500 hover:underline"
                  >
                    View general APPR guidelines
                  </a>
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </Layout>
  );
}

function getScenarioTitle(scenario: ScenarioType): string {
  const titles = {
    'delay': 'Flight Delay',
    'cancellation': 'Flight Cancellation',
    'denied-boarding': 'Denied Boarding',
    'baggage': 'Baggage Issues',
    'refund': 'Refund Eligibility'
  };
  
  return titles[scenario] || 'Unknown Scenario';
}
