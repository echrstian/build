import type { NextApiRequest, NextApiResponse } from 'next';
import { storage } from '../../../server/storage';
import { Airline } from '../../../shared/schema';

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse<Airline[] | { error: string }>
) {
  if (req.method === 'GET') {
    try {
      const airlines = await storage.getAllAirlines();
      return res.status(200).json(airlines);
    } catch (error) {
      console.error('Error fetching airlines:', error);
      return res.status(500).json({ error: 'Failed to fetch airlines' });
    }
  } else {
    return res.status(405).json({ error: 'Method not allowed' });
  }
}