import type { NextApiRequest, NextApiResponse } from 'next';
import { storage } from '../../../../server/storage';
import { Right } from '../../../../shared/schema';

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse<Right[] | { error: string }>
) {
  const { airlineId } = req.query;

  if (!airlineId || typeof airlineId !== 'string') {
    return res.status(400).json({ error: 'Missing or invalid airline ID' });
  }

  if (req.method === 'GET') {
    try {
      const airlineIdNumber = parseInt(airlineId, 10);
      
      if (isNaN(airlineIdNumber)) {
        return res.status(400).json({ error: 'Invalid airline ID format' });
      }
      
      const rights = await storage.getRightsByAirline(airlineIdNumber);
      return res.status(200).json(rights);
    } catch (error) {
      console.error(`Error fetching rights for airline ID ${airlineId}:`, error);
      return res.status(500).json({ error: 'Failed to fetch rights' });
    }
  } else {
    return res.status(405).json({ error: 'Method not allowed' });
  }
}