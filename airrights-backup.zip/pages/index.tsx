import Head from 'next/head';
import { useState } from 'react';
import Layout from '../components/Layout';
import RightsWizard from '../components/RightsWizard';
import { Inter } from 'next/font/google';
import Link from 'next/link';

const inter = Inter({ subsets: ['latin'] });

export default function Home() {
  const [showWizard, setShowWizard] = useState(false);
  
  return (
    <Layout>
      <Head>
        <title>AirRights Canada - Know Your Passenger Rights</title>
        <meta name="description" content="Learn about your rights as an airline passenger in Canada under the Air Passenger Protection Regulations (APPR)" />
        <link rel="icon" href="/favicon.ico" />
      </Head>
      
      <main className={`flex min-h-screen flex-col items-center px-4 ${inter.className}`}>
        <div className="container mx-auto max-w-6xl py-12">
          <div className="text-center mb-16">
            <h1 className="text-4xl md:text-5xl font-bold mb-6 text-gray-800">
              Know Your <span className="text-blue-500">Rights</span> as an Airline Passenger in Canada
            </h1>
            <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
              AirRights Canada helps you understand your legal protections under the Canadian Transportation Agency's Air Passenger Protection Regulations.
            </p>
            
            <div className="mt-10 space-x-4">
              <button 
                className="bg-blue-500 text-white px-6 py-3 rounded-md hover:bg-blue-600 transition-colors text-lg font-medium"
                onClick={() => setShowWizard(true)}
              >
                What Are My Rights?
              </button>
              <Link href="/faq" className="inline-block bg-white text-blue-500 border border-blue-500 px-6 py-3 rounded-md hover:bg-blue-50 transition-colors text-lg font-medium">
                View FAQ
              </Link>
            </div>
          </div>
          
          {showWizard ? (
            <RightsWizard onClose={() => setShowWizard(false)} />
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mt-12">
              <FeatureCard 
                title="Flight Delays & Cancellations" 
                description="Learn about compensation for delays and cancellations based on the airline's control."
                icon="⏱️"
                href="/airlines?scenario=delay"
              />
              <FeatureCard 
                title="Denied Boarding" 
                description="Understand your rights when you're bumped from your flight due to overbooking."
                icon="🚫"
                href="/airlines?scenario=denied-boarding"
              />
              <FeatureCard 
                title="Lost or Damaged Luggage" 
                description="Know the compensation you're entitled to for baggage issues." 
                icon="🧳"
                href="/airlines?scenario=baggage"
              />
              <FeatureCard 
                title="Airline-Specific Rights" 
                description="View rights information for specific Canadian airlines."
                icon="✈️"
                href="/airlines"
              />
              <FeatureCard 
                title="File a Complaint" 
                description="Learn how to properly file a complaint with the airline or the CTA."
                icon="📝"
                href="/contact"
              />
              <FeatureCard 
                title="About APPR" 
                description="Learn about the Air Passenger Protection Regulations in Canada."
                icon="📋"
                href="/about"
              />
            </div>
          )}
        </div>
      </main>
    </Layout>
  );
}

interface FeatureCardProps {
  title: string;
  description: string;
  icon: string;
  href: string;
}

const FeatureCard = ({ title, description, icon, href }: FeatureCardProps) => (
  <Link href={href} className="block">
    <div className="bg-white rounded-lg p-6 shadow-md hover:shadow-lg transition-shadow border border-gray-200 h-full">
      <div className="text-4xl mb-4">{icon}</div>
      <h3 className="text-xl font-semibold mb-2 text-gray-800">{title}</h3>
      <p className="text-gray-600">{description}</p>
    </div>
  </Link>
);
