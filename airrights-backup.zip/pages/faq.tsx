import Head from 'next/head';
import { useState } from 'react';
import Layout from '../components/Layout';
import Link from 'next/link';

export default function FAQ() {
  const [openItem, setOpenItem] = useState<number | null>(null);
  
  const toggleItem = (index: number) => {
    setOpenItem(openItem === index ? null : index);
  };
  
  const faqItems = [
    {
      question: "What are the Air Passenger Protection Regulations?",
      answer: "The Air Passenger Protection Regulations (APPR) are rules established by the Canadian Transportation Agency (CTA) that set out airlines' obligations to passengers in situations such as flight delays and cancellations, denied boarding, lost or damaged baggage, and more. These regulations apply to all flights to, from, and within Canada."
    },
    {
      question: "Which airlines are covered by these regulations?",
      answer: "The APPR apply to all flights to, from, and within Canada, including connecting flights. This includes both Canadian carriers (like Air Canada, WestJet) and foreign carriers operating flights to and from Canada."
    },
    {
      question: "What compensation am I entitled to for flight delays?",
      answer: "Compensation depends on the reason for delay and how late you arrive at your destination. For delays within the airline's control, you may be entitled to $400-$1,000 CAD, depending on the size of the airline and length of delay. No compensation is owed for delays due to safety reasons or factors outside the airline's control (like weather)."
    },
    {
      question: "What should I do if my flight is cancelled?",
      answer: "If your flight is cancelled, the airline must rebook you on the next available flight or provide a refund at your choice. For cancellations within the airline's control, you may be entitled to compensation of $400-$1,000 CAD. Document everything, including communications with the airline, and keep your boarding pass and receipts."
    },
    {
      question: "What rights do I have if I'm denied boarding (bumped)?",
      answer: "If you're denied boarding due to overbooking or for reasons within the airline's control, you're entitled to compensation of $900-$2,400 CAD depending on the delay length, rebooking on the next available flight, and standards of treatment while waiting (meals, accommodation if needed)."
    },
    {
      question: "Am I entitled to compensation for lost or damaged baggage?",
      answer: "Yes. For domestic flights, airlines are liable for up to approximately $2,300 CAD per passenger for lost, damaged, or delayed baggage. For international flights, liability is limited to about 1,288 Special Drawing Rights (approximately $2,400 CAD). Report baggage problems immediately and keep all receipts for necessities purchased."
    },
    {
      question: "What standards of treatment must airlines provide during delays?",
      answer: "For delays of 2+ hours that are within the airline's control, they must provide: food and drink, access to communication (like free WiFi), and for overnight delays, hotel accommodation and transportation to/from the hotel."
    },
    {
      question: "How do I file a complaint with an airline or the CTA?",
      answer: "First, submit a written complaint to your airline and give them 30 days to respond. If you're not satisfied with their response, you can file a complaint with the CTA through their website or by calling 1-888-222-2592. Keep all documentation related to your flight and the issue."
    },
    {
      question: "Do these regulations apply to flights disrupted by COVID-19?",
      answer: "The CTA has issued special statements regarding COVID-19 disruptions. Generally, pandemic-related cancellations are considered outside the airline's control, affecting compensation requirements. However, airlines must still provide rebooking or refunds depending on circumstances."
    },
    {
      question: "Can airlines refuse compensation by claiming 'safety reasons'?",
      answer: "Airlines don't have to provide compensation for delays or cancellations due to safety reasons. However, they must provide evidence that the issue was genuinely safety-related if requested by the CTA. Airlines cannot merely label an issue as 'safety' to avoid compensation."
    }
  ];
  
  return (
    <Layout>
      <Head>
        <title>Frequently Asked Questions | AirRights Canada</title>
        <meta 
          name="description" 
          content="Find answers to common questions about airline passenger rights in Canada under the Air Passenger Protection Regulations (APPR)." 
        />
      </Head>
      
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <Link href="/" className="text-blue-500 hover:underline mb-4 inline-block">
            &larr; Back to Home
          </Link>
          <h1 className="text-3xl md:text-4xl font-bold mb-4">Frequently Asked Questions</h1>
          <p className="text-gray-600 mb-6">Find answers to common questions about airline passenger rights in Canada.</p>
        </div>
        
        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <div className="divide-y divide-gray-200">
            {faqItems.map((item, index) => (
              <div key={index} className="py-4">
                <button
                  className="flex justify-between items-center w-full text-left font-medium text-gray-800 hover:text-blue-500 focus:outline-none"
                  onClick={() => toggleItem(index)}
                >
                  <span className="text-lg">{item.question}</span>
                  <svg 
                    className={`w-5 h-5 transform transition-transform ${openItem === index ? 'rotate-180' : ''}`} 
                    fill="none" 
                    stroke="currentColor" 
                    viewBox="0 0 24 24"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
                  </svg>
                </button>
                
                {openItem === index && (
                  <div className="mt-2 text-gray-600">
                    <p className="py-2">{item.answer}</p>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
        
        <div className="bg-blue-50 rounded-lg p-6 border border-blue-100">
          <h2 className="text-xl font-semibold mb-4">Need More Information?</h2>
          <p className="mb-4">For the most accurate and up-to-date information, visit the official Canadian Transportation Agency website:</p>
          <a 
            href="https://rppa-appr.ca/eng/air-passenger-protection-regulations" 
            target="_blank" 
            rel="noopener noreferrer"
            className="bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600 inline-flex items-center"
          >
            Visit Official CTA Website
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 ml-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path>
              <polyline points="15 3 21 3 21 9"></polyline>
              <line x1="10" y1="14" x2="21" y2="3"></line>
            </svg>
          </a>
        </div>
      </div>
    </Layout>
  );
}
