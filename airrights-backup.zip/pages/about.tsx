import Head from 'next/head';
import Layout from '../components/Layout';
import Link from 'next/link';

export default function About() {
  return (
    <Layout>
      <Head>
        <title>About AirRights Canada</title>
        <meta 
          name="description" 
          content="Learn about AirRights Canada and the Air Passenger Protection Regulations (APPR) that protect airline passengers in Canada." 
        />
      </Head>
      
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <Link href="/" className="text-blue-500 hover:underline mb-4 inline-block">
            &larr; Back to Home
          </Link>
          <h1 className="text-3xl md:text-4xl font-bold mb-4">About AirRights Canada</h1>
        </div>
        
        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <section className="mb-8">
            <h2 className="text-2xl font-semibold mb-4">Our Mission</h2>
            <p className="text-gray-700 mb-4">
              AirRights Canada was created to help airline passengers in Canada understand their legal rights under the 
              Canadian Transportation Agency's Air Passenger Protection Regulations (APPR). Our goal is to empower 
              travelers with clear, actionable information so they can advocate for themselves when travel disruptions occur.
            </p>
            <p className="text-gray-700">
              We believe that informed passengers can better navigate the complexities of air travel disruptions and receive 
              the compensation and assistance they're legally entitled to under Canadian law.
            </p>
          </section>
          
          <section className="mb-8">
            <h2 className="text-2xl font-semibold mb-4">About the APPR</h2>
            <p className="text-gray-700 mb-4">
              The Air Passenger Protection Regulations came into effect in two phases in 2019. These regulations establish 
              airlines' minimum obligations to passengers in situations such as:
            </p>
            <ul className="list-disc list-inside mb-4 text-gray-700">
              <li className="mb-2">Flight delays and cancellations</li>
              <li className="mb-2">Denied boarding (being "bumped")</li>
              <li className="mb-2">Lost or damaged baggage</li>
              <li className="mb-2">Tarmac delays</li>
              <li className="mb-2">Seating of children</li>
              <li>Communications</li>
            </ul>
            <p className="text-gray-700">
              The regulations apply to all flights to, from and within Canada, including connecting flights. 
              This means both Canadian and international airlines must comply with these regulations for their 
              Canadian operations.
            </p>
          </section>
          
          <section className="mb-8">
            <h2 className="text-2xl font-semibold mb-4">Legal Disclaimer</h2>
            <div className="bg-gray-50 p-4 rounded-md border border-gray-200">
              <p className="text-gray-700 mb-4">
                The information provided on AirRights Canada is for general informational purposes only. It is 
                not intended to be legal advice, and should not be treated as such.
              </p>
              <p className="text-gray-700 mb-4">
                While we strive for accuracy, we cannot guarantee that all information on this site is current 
                or correct. Regulations can change, and airline policies may differ. Always confirm information 
                with official sources.
              </p>
              <p className="text-gray-700">
                For official information about passenger rights, please visit the 
                <a href="https://rppa-appr.ca/eng" target="_blank" rel="noopener noreferrer" className="text-blue-500 hover:underline"> Canadian Transportation Agency's website</a>.
              </p>
            </div>
          </section>
          
          <section>
            <h2 className="text-2xl font-semibold mb-4">Data Sources</h2>
            <p className="text-gray-700 mb-4">
              The information on AirRights Canada is compiled from the following authoritative sources:
            </p>
            <ul className="list-disc list-inside text-gray-700">
              <li className="mb-2">
                <a href="https://rppa-appr.ca/eng" target="_blank" rel="noopener noreferrer" className="text-blue-500 hover:underline">
                  Canadian Transportation Agency (CTA)
                </a>
              </li>
              <li className="mb-2">
                <a href="https://tc.canada.ca/en/aviation" target="_blank" rel="noopener noreferrer" className="text-blue-500 hover:underline">
                  Transport Canada
                </a>
              </li>
              <li className="mb-2">
                <a href="https://otc-cta.gc.ca/eng/decisions" target="_blank" rel="noopener noreferrer" className="text-blue-500 hover:underline">
                  CTA Decisions
                </a>
              </li>
              <li>
                Official airline tariffs and policies as published by individual carriers
              </li>
            </ul>
          </section>
        </div>
      </div>
    </Layout>
  );
}
