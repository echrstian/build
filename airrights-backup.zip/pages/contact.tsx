import Head from 'next/head';
import Layout from '../components/Layout';
import Link from 'next/link';

export default function Contact() {
  return (
    <Layout>
      <Head>
        <title>Contact & File a Complaint | AirRights Canada</title>
        <meta 
          name="description" 
          content="Learn how to file a complaint with an airline or the Canadian Transportation Agency about a flight issue." 
        />
      </Head>
      
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <Link href="/" className="text-blue-500 hover:underline mb-4 inline-block">
            &larr; Back to Home
          </Link>
          <h1 className="text-3xl md:text-4xl font-bold mb-4">File a Complaint</h1>
          <p className="text-gray-600 mb-6">Learn how to properly file a complaint about an airline issue.</p>
        </div>
        
        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <section className="mb-8">
            <h2 className="text-2xl font-semibold mb-4">Complaint Process</h2>
            <div className="space-y-6">
              <div className="bg-blue-50 p-4 rounded-md border border-blue-100">
                <h3 className="text-lg font-medium mb-2 text-blue-800">Step 1: Contact the Airline First</h3>
                <p className="text-gray-700 mb-2">
                  The CTA requires that you first submit a complaint directly to the airline and give them 30 days to respond.
                </p>
                <p className="text-gray-700">
                  Document everything: Keep copies of all communications with the airline, boarding passes, receipts, and any other relevant documents.
                </p>
              </div>
              
              <div className="bg-blue-50 p-4 rounded-md border border-blue-100">
                <h3 className="text-lg font-medium mb-2 text-blue-800">Step 2: File a Complaint with the CTA</h3>
                <p className="text-gray-700 mb-4">
                  If you're not satisfied with the airline's response (or don't receive one within 30 days), you can file a complaint with the Canadian Transportation Agency.
                </p>
                <a 
                  href="https://rppa-appr.ca/eng/file-complaint-about-air-carrier" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600 inline-flex items-center"
                >
                  File a Complaint with the CTA
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 ml-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path>
                    <polyline points="15 3 21 3 21 9"></polyline>
                    <line x1="10" y1="14" x2="21" y2="3"></line>
                  </svg>
                </a>
              </div>
            </div>
          </section>
          
          <section className="mb-8">
            <h2 className="text-2xl font-semibold mb-4">Airline Contact Information</h2>
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Airline</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Complaint Form</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Customer Service</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  <tr>
                    <td className="px-6 py-4 whitespace-nowrap">Air Canada</td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <a 
                        href="https://www.aircanada.com/ca/en/aco/home/fly/customer-support/customer-relations.html" 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="text-blue-500 hover:underline"
                      >
                        Online Form
                      </a>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">1-888-247-2262</td>
                  </tr>
                  <tr>
                    <td className="px-6 py-4 whitespace-nowrap">WestJet</td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <a 
                        href="https://www.westjet.com/en-ca/contact-us/index" 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="text-blue-500 hover:underline"
                      >
                        Online Form
                      </a>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">1-888-937-8538</td>
                  </tr>
                  <tr>
                    <td className="px-6 py-4 whitespace-nowrap">Porter Airlines</td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <a 
                        href="https://www.flyporter.com/en-ca/about-us/contact-us" 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="text-blue-500 hover:underline"
                      >
                        Online Form
                      </a>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">1-888-619-8622</td>
                  </tr>
                  <tr>
                    <td className="px-6 py-4 whitespace-nowrap">Flair Airlines</td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <a 
                        href="https://flyflair.com/travel-info/customer-service/" 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="text-blue-500 hover:underline"
                      >
                        Online Form
                      </a>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">1-833-700-2244</td>
                  </tr>
                  <tr>
                    <td className="px-6 py-4 whitespace-nowrap">Air Transat</td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <a 
                        href="https://www.airtransat.com/en-CA/Contact-us" 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="text-blue-500 hover:underline"
                      >
                        Online Form
                      </a>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">1-877-872-6728</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </section>
          
          <section className="mb-8">
            <h2 className="text-2xl font-semibold mb-4">Tips for Filing an Effective Complaint</h2>
            <ul className="list-disc list-inside space-y-2 text-gray-700">
              <li>Be clear, concise, and specific about the incident.</li>
              <li>Include all relevant details: flight numbers, dates, times, locations.</li>
              <li>Attach copies of supporting documents (boarding passes, receipts, etc.).</li>
              <li>Specify what resolution you're seeking (compensation, reimbursement, etc.).</li>
              <li>Keep your communication professional and factual.</li>
              <li>Follow up if you don't receive a response within the expected timeframe.</li>
              <li>Keep records of all communications with the airline and the CTA.</li>
            </ul>
          </section>
          
          <section>
            <h2 className="text-2xl font-semibold mb-4">Canadian Transportation Agency Contact</h2>
            <div className="bg-gray-50 p-4 rounded-md border border-gray-200">
              <p className="text-gray-700 mb-2"><strong>Phone:</strong> 1-888-222-2592</p>
              <p className="text-gray-700 mb-2"><strong>TTY:</strong> 1-800-669-5575</p>
              <p className="text-gray-700 mb-2">
                <strong>Mail:</strong><br />
                Canadian Transportation Agency<br />
                Ottawa, Ontario K1A 0N9<br />
                Canada
              </p>
              <p className="text-gray-700">
                <strong>Website:</strong> 
                <a 
                  href="https://otc-cta.gc.ca/eng" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-blue-500 hover:underline"
                >
                  https://otc-cta.gc.ca/eng
                </a>
              </p>
            </div>
          </section>
        </div>
      </div>
    </Layout>
  );
}
