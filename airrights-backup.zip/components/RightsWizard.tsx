import { useState, useEffect } from 'react';
import { useRouter } from 'next/router';
import { api } from '../utils/supabaseClient';
import LoadingSpinner from './LoadingSpinner';
import { Airline, Right, ScenarioType } from '../utils/types';

interface RightsWizardProps {
  onClose: () => void;
}

export default function RightsWizard({ onClose }: RightsWizardProps) {
  const [step, setStep] = useState(1);
  const [airlines, setAirlines] = useState<Airline[]>([]);
  const [selectedAirline, setSelectedAirline] = useState<Airline | null>(null);
  const [selectedScenario, setSelectedScenario] = useState<ScenarioType | null>(null);
  const [result, setResult] = useState<Right | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  
  const router = useRouter();
  
  const scenarios = [
    { type: 'delay' as ScenarioType, label: 'Flight Delay', icon: '⏱️' },
    { type: 'cancellation' as ScenarioType, label: 'Flight Cancellation', icon: '❌' },
    { type: 'denied-boarding' as ScenarioType, label: 'Denied Boarding (Bumping)', icon: '🚫' },
    { type: 'baggage' as ScenarioType, label: 'Lost or Damaged Baggage', icon: '🧳' },
    { type: 'refund' as ScenarioType, label: 'Refund Request', icon: '💵' }
  ];
  
  // Fetch airlines on component mount
  useEffect(() => {
    const fetchAirlines = async () => {
      try {
        setLoading(true);
        const airlines = await api.getAllAirlines();
        setAirlines(airlines);
      } catch (err) {
        console.error('Error fetching airlines:', err);
        setError(err instanceof Error ? err.message : 'Failed to load airlines');
      } finally {
        setLoading(false);
      }
    };
    
    fetchAirlines();
  }, []);
  
  // Step 3: Fetch rights based on airline and scenario
  useEffect(() => {
    if (step === 3 && selectedAirline && selectedScenario) {
      const fetchRights = async () => {
        try {
          setLoading(true);
          // Convert string ID to number if needed
          const airlineId = typeof selectedAirline.id === 'string' 
            ? parseInt(selectedAirline.id, 10)
            : selectedAirline.id;
          
          try {
            const right = await api.getRightsByScenario(airlineId, selectedScenario);
            setResult(right);
          } catch (err) {
            console.error('Error fetching rights:', err);
            // Just set result to null if we can't find specific rights data
            // This will show the general information message
            setResult(null);
          }
        } catch (err) {
          console.error('Error fetching rights:', err);
          setError(err instanceof Error ? err.message : 'Failed to load rights information');
        } finally {
          setLoading(false);
        }
      };
      
      fetchRights();
    }
  }, [step, selectedAirline, selectedScenario]);
  
  const handleAirlineSelect = (airline: Airline) => {
    setSelectedAirline(airline);
    setStep(2);
  };
  
  const handleScenarioSelect = (scenario: ScenarioType) => {
    setSelectedScenario(scenario);
    setStep(3);
  };
  
  const handleViewDetails = () => {
    if (selectedAirline && selectedScenario) {
      router.push(`/airlines/${selectedAirline.slug}?scenario=${selectedScenario}`);
    }
  };
  
  const renderStepContent = () => {
    if (loading) {
      return (
        <div className="flex justify-center items-center py-12">
          <LoadingSpinner />
        </div>
      );
    }
    
    if (error) {
      return (
        <div className="text-center py-8">
          <div className="text-red-500 mb-4">{error}</div>
          <button
            onClick={() => setError('')}
            className="bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600"
          >
            Try Again
          </button>
        </div>
      );
    }
    
    switch (step) {
      case 1:
        return (
          <div>
            <h3 className="text-xl font-semibold mb-4">Select Your Airline</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {airlines.map((airline) => (
                <button
                  key={airline.id}
                  onClick={() => handleAirlineSelect(airline)}
                  className="flex items-center p-4 border border-gray-200 rounded-md hover:bg-blue-50 transition-colors"
                >
                  <span className="text-lg mr-2">✈️</span>
                  <span>{airline.name} {airline.iata_code ? `(${airline.iata_code})` : ''}</span>
                </button>
              ))}
            </div>
          </div>
        );
        
      case 2:
        return (
          <div>
            <h3 className="text-xl font-semibold mb-4">What issue are you facing?</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {scenarios.map((scenario) => (
                <button
                  key={scenario.type}
                  onClick={() => handleScenarioSelect(scenario.type)}
                  className="flex items-center p-4 border border-gray-200 rounded-md hover:bg-blue-50 transition-colors"
                >
                  <span className="text-lg mr-2">{scenario.icon}</span>
                  <span>{scenario.label}</span>
                </button>
              ))}
            </div>
          </div>
        );
        
      case 3:
        return (
          <div>
            <h3 className="text-xl font-semibold mb-4">
              Your Rights: {selectedAirline?.name} - {getScenarioTitle(selectedScenario || 'delay')}
            </h3>
            
            {result ? (
              <div className="bg-blue-50 p-4 rounded-md">
                {result.compensation_amount && (
                  <div className="mb-4">
                    <h4 className="font-medium">Compensation:</h4>
                    <p>{result.compensation_amount}</p>
                  </div>
                )}
                
                {result.eligibility_criteria && (
                  <div className="mb-4">
                    <h4 className="font-medium">Eligibility Criteria:</h4>
                    <p>{result.eligibility_criteria}</p>
                  </div>
                )}
                
                {result.legal_reference && (
                  <div className="text-sm text-gray-600 mb-4">
                    <h4 className="font-medium">Legal Reference:</h4>
                    <p>{result.legal_reference}</p>
                  </div>
                )}
                
                <div className="mt-6">
                  <button
                    onClick={handleViewDetails}
                    className="bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600"
                  >
                    View Detailed Information
                  </button>
                </div>
              </div>
            ) : (
              <div className="text-center py-6">
                <p className="mb-4">
                  We don't have specific information for this scenario, but you can review general rights under the APPR.
                </p>
                <a
                  href="https://rppa-appr.ca/eng/air-passenger-protection-regulations"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600 inline-block"
                >
                  View APPR Guidelines
                </a>
              </div>
            )}
          </div>
        );
        
      default:
        return null;
    }
  };
  
  return (
    <div className="bg-white rounded-lg shadow-md p-6 relative">
      <button
        onClick={onClose}
        className="absolute top-4 right-4 text-gray-400 hover:text-gray-600"
        aria-label="Close wizard"
      >
        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
        </svg>
      </button>
      
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-center">What Are My Rights?</h2>
        <p className="text-gray-600 text-center">Let's find your passenger rights under Canadian regulations</p>
      </div>
      
      {/* Progress steps */}
      <div className="flex items-center justify-center mb-8">
        <div className={`w-8 h-8 rounded-full flex items-center justify-center ${step >= 1 ? 'bg-blue-500 text-white' : 'bg-gray-200 text-gray-600'}`}>
          1
        </div>
        <div className={`w-12 h-1 ${step >= 2 ? 'bg-blue-500' : 'bg-gray-200'}`}></div>
        <div className={`w-8 h-8 rounded-full flex items-center justify-center ${step >= 2 ? 'bg-blue-500 text-white' : 'bg-gray-200 text-gray-600'}`}>
          2
        </div>
        <div className={`w-12 h-1 ${step >= 3 ? 'bg-blue-500' : 'bg-gray-200'}`}></div>
        <div className={`w-8 h-8 rounded-full flex items-center justify-center ${step >= 3 ? 'bg-blue-500 text-white' : 'bg-gray-200 text-gray-600'}`}>
          3
        </div>
      </div>
      
      {renderStepContent()}
      
      {/* Navigation buttons */}
      <div className="mt-8 flex justify-between">
        {step > 1 ? (
          <button
            onClick={() => setStep(step - 1)}
            className="text-blue-500 hover:underline flex items-center"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M19 12H5M12 19l-7-7 7-7"/>
            </svg>
            Back
          </button>
        ) : (
          <div></div>
        )}
        
        <button
          onClick={onClose}
          className="text-gray-500 hover:underline"
        >
          Cancel
        </button>
      </div>
    </div>
  );
}

function getScenarioTitle(scenario: string): string {
  const titles: { [key: string]: string } = {
    'delay': 'Flight Delay',
    'cancellation': 'Flight Cancellation',
    'denied-boarding': 'Denied Boarding',
    'baggage': 'Baggage Issues',
    'refund': 'Refund Eligibility'
  };
  
  return titles[scenario] || 'Unknown Scenario';
}
