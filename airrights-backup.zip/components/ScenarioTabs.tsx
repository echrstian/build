import { ScenarioType } from '../utils/types';

interface ScenarioTabsProps {
  activeScenario: ScenarioType;
  onChange: (scenario: ScenarioType) => void;
}

export default function ScenarioTabs({ activeScenario, onChange }: ScenarioTabsProps) {
  const scenarios: { type: ScenarioType; label: string; icon: string }[] = [
    { type: 'delay', label: 'Flight Delays', icon: '⏱️' },
    { type: 'cancellation', label: 'Cancellations', icon: '❌' },
    { type: 'denied-boarding', label: 'Denied Boarding', icon: '🚫' },
    { type: 'baggage', label: 'Baggage Issues', icon: '🧳' },
    { type: 'refund', label: 'Refunds', icon: '💵' }
  ];

  return (
    <div className="border-b border-gray-200">
      <nav className="-mb-px flex space-x-1 overflow-x-auto">
        {scenarios.map((scenario) => (
          <button
            key={scenario.type}
            onClick={() => onChange(scenario.type)}
            className={`
              whitespace-nowrap py-3 px-3 border-b-2 font-medium text-sm
              ${activeScenario === scenario.type
                ? 'border-blue-500 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'}
            `}
          >
            <span className="mr-2">{scenario.icon}</span>
            {scenario.label}
          </button>
        ))}
      </nav>
    </div>
  );
}
