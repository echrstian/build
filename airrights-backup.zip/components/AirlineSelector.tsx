import { useState, useEffect } from 'react';
import { useRouter } from 'next/router';
import { api } from '../utils/supabaseClient';
import { Airline } from '../utils/types';
import LoadingSpinner from './LoadingSpinner';

interface AirlineSelectorProps {
  onSelect: (airline: Airline) => void;
  selectedAirlineId?: string;
}

export default function AirlineSelector({ onSelect, selectedAirlineId }: AirlineSelectorProps) {
  const [airlines, setAirlines] = useState<Airline[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const router = useRouter();

  useEffect(() => {
    const fetchAirlines = async () => {
      try {
        setLoading(true);
        const data = await api.getAllAirlines();
        
        // Sort the airlines by name
        const sortedAirlines = [...data].sort((a, b) => a.name.localeCompare(b.name));
        
        setAirlines(sortedAirlines);
        
        // If there's a selected airline ID and we have airlines loaded, find and select it
        if (selectedAirlineId && sortedAirlines.length > 0) {
          const selectedAirline = sortedAirlines.find(airline => 
            airline.id.toString() === selectedAirlineId
          );
          
          if (selectedAirline) {
            onSelect(selectedAirline);
          }
        }
      } catch (err) {
        console.error('Error fetching airlines:', err);
        setError(err instanceof Error ? err.message : 'Failed to load airlines');
      } finally {
        setLoading(false);
      }
    };
    
    fetchAirlines();
  }, [selectedAirlineId, onSelect]);

  const handleAirlineChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const airlineId = e.target.value;
    const selectedAirline = airlines.find(airline => airline.id === airlineId);
    if (selectedAirline) {
      onSelect(selectedAirline);
      router.push(`/airlines/${selectedAirline.slug}`);
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center p-4">
        <LoadingSpinner />
      </div>
    );
  }

  if (error) {
    return <div className="text-red-500 p-2">{error}</div>;
  }

  if (airlines.length === 0) {
    return <div className="text-gray-500 p-2">No airlines available</div>;
  }

  return (
    <div className="w-full">
      <label htmlFor="airline-select" className="block text-sm font-medium text-gray-700 mb-1">
        Select Airline
      </label>
      <select
        id="airline-select"
        value={selectedAirlineId || ''}
        onChange={handleAirlineChange}
        className="block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
      >
        <option value="" disabled>Select an airline</option>
        {airlines.map((airline) => (
          <option key={airline.id} value={airline.id}>
            {airline.name} {airline.iata_code ? `(${airline.iata_code})` : ''}
          </option>
        ))}
      </select>
    </div>
  );
}
