import Link from 'next/link';

export default function Footer() {
  return (
    <footer className="bg-gray-800 text-white mt-12">
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <h3 className="text-lg font-semibold mb-4">AirRights Canada</h3>
            <p className="text-gray-300 text-sm">
              Helping Canadian airline passengers understand their rights under the Air Passenger Protection Regulations.
            </p>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2 text-gray-300 text-sm">
              <li>
                <Link href="/" className="hover:text-blue-300 transition-colors">
                  Home
                </Link>
              </li>
              <li>
                <Link href="/airlines/air-canada" className="hover:text-blue-300 transition-colors">
                  Airlines
                </Link>
              </li>
              <li>
                <Link href="/faq" className="hover:text-blue-300 transition-colors">
                  FAQ
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Resources</h3>
            <ul className="space-y-2 text-gray-300 text-sm">
              <li>
                <a 
                  href="https://rppa-appr.ca/eng/air-passenger-protection-regulations" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="hover:text-blue-300 transition-colors"
                >
                  APPR Regulations
                </a>
              </li>
              <li>
                <a 
                  href="https://otc-cta.gc.ca/eng" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="hover:text-blue-300 transition-colors"
                >
                  Canadian Transportation Agency
                </a>
              </li>
              <li>
                <a 
                  href="https://tc.canada.ca/en/aviation/guidelines-passenger-rights" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="hover:text-blue-300 transition-colors"
                >
                  Transport Canada
                </a>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Legal</h3>
            <ul className="space-y-2 text-gray-300 text-sm">
              <li>
                <Link href="/about" className="hover:text-blue-300 transition-colors">
                  Disclaimer
                </Link>
              </li>
              <li>
                <Link href="/contact" className="hover:text-blue-300 transition-colors">
                  File a Complaint
                </Link>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-700 mt-8 pt-6 text-center text-sm text-gray-400">
          <p>
            AirRights Canada provides information, not legal advice. For official information, visit the 
            <a 
              href="https://otc-cta.gc.ca/eng" 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-blue-300 hover:underline ml-1"
            >
              Canadian Transportation Agency website
            </a>.
          </p>
          <p className="mt-2">
            &copy; {new Date().getFullYear()} AirRights Canada. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}
