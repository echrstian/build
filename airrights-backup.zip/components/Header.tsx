import { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/router';

export default function Header() {
  const [menuOpen, setMenuOpen] = useState(false);
  const router = useRouter();
  
  const isActive = (path: string) => {
    return router.pathname === path ? 'text-blue-500' : 'text-gray-700 hover:text-blue-500';
  };
  
  return (
    <header className="bg-white shadow-sm">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <Link href="/" className="flex items-center">
              <span className="text-2xl text-blue-500 font-bold mr-2">✈️</span>
              <span className="font-bold text-xl text-gray-800">AirRights</span>
              <span className="font-bold text-xl text-blue-500">Canada</span>
            </Link>
          </div>
          
          {/* Desktop navigation */}
          <nav className="hidden md:flex space-x-8">
            <Link href="/" className={`${isActive('/')} font-medium transition-colors`}>
              Home
            </Link>
            <Link href="/airlines" className={`${isActive('/airlines')} font-medium transition-colors`}>
              Airlines
            </Link>
            <Link href="/faq" className={`${isActive('/faq')} font-medium transition-colors`}>
              FAQ
            </Link>
            <Link href="/about" className={`${isActive('/about')} font-medium transition-colors`}>
              About
            </Link>
            <Link href="/contact" className={`${isActive('/contact')} font-medium transition-colors`}>
              Contact
            </Link>
          </nav>
          
          {/* Mobile menu button */}
          <div className="md:hidden">
            <button 
              onClick={() => setMenuOpen(!menuOpen)}
              className="text-gray-500 hover:text-gray-700 focus:outline-none"
            >
              <svg 
                xmlns="http://www.w3.org/2000/svg" 
                className="h-6 w-6" 
                fill="none" 
                viewBox="0 0 24 24" 
                stroke="currentColor"
              >
                {menuOpen ? (
                  <path 
                    strokeLinecap="round" 
                    strokeLinejoin="round" 
                    strokeWidth={2} 
                    d="M6 18L18 6M6 6l12 12" 
                  />
                ) : (
                  <path 
                    strokeLinecap="round" 
                    strokeLinejoin="round" 
                    strokeWidth={2} 
                    d="M4 6h16M4 12h16M4 18h16" 
                  />
                )}
              </svg>
            </button>
          </div>
        </div>
        
        {/* Mobile navigation */}
        {menuOpen && (
          <div className="md:hidden">
            <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
              <Link 
                href="/" 
                className={`${isActive('/')} block px-3 py-2 rounded-md text-base font-medium`}
                onClick={() => setMenuOpen(false)}
              >
                Home
              </Link>
              <Link 
                href="/airlines" 
                className={`${isActive('/airlines')} block px-3 py-2 rounded-md text-base font-medium`}
                onClick={() => setMenuOpen(false)}
              >
                Airlines
              </Link>
              <Link 
                href="/faq" 
                className={`${isActive('/faq')} block px-3 py-2 rounded-md text-base font-medium`}
                onClick={() => setMenuOpen(false)}
              >
                FAQ
              </Link>
              <Link 
                href="/about" 
                className={`${isActive('/about')} block px-3 py-2 rounded-md text-base font-medium`}
                onClick={() => setMenuOpen(false)}
              >
                About
              </Link>
              <Link 
                href="/contact" 
                className={`${isActive('/contact')} block px-3 py-2 rounded-md text-base font-medium`}
                onClick={() => setMenuOpen(false)}
              >
                Contact
              </Link>
            </div>
          </div>
        )}
      </div>
    </header>
  );
}
