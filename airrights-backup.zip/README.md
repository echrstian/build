# AirRights Canada

## Description

AirRights Canada is a web application designed to educate Canadian airline passengers about their legal rights under the Air Passenger Protection Regulations (APPR). The platform provides detailed information on compensation eligibility for scenarios such as flight delays, cancellations, denied boarding, and baggage issues.

## Features

- **Airline-specific Information**: Browse passenger rights information for major Canadian airlines
- **Scenario-based Guidance**: Find detailed compensation information for specific situations:
  - Flight delays
  - Flight cancellations
  - Denied boarding
  - Baggage issues
  - Refund eligibility
- **Interactive Rights Wizard**: Answer a few questions to determine your specific compensation entitlements
- **Easy Navigation**: Compare rights across different airlines
- **Legal References**: Access to direct quotes from relevant APPR regulations

## Technology Stack

- **Frontend**: Next.js, React, TypeScript, Tailwind CSS
- **Database**: PostgreSQL with Drizzle ORM
- **API**: RESTful endpoints for retrieving airline and rights information

## Setup and Installation

### Prerequisites

- Node.js (v14+)
- PostgreSQL database

### Installation Steps

1. Clone the repository
   ```
   git clone https://github.com/yourusername/airrights-canada.git
   cd airrights-canada
   ```

2. Install dependencies
   ```
   npm install
   ```

3. Set up environment variables
   Create a `.env` file in the root directory with the following variables:
   ```
   DATABASE_URL=postgresql://username:password@localhost:5432/airrights
   ```

4. Set up the database
   ```
   npm run db:push
   npm run db:seed
   ```

5. Start the development server
   ```
   npm run dev
   ```

6. The application will be available at `http://localhost:5000`

## Database Structure

The application uses three main tables:

- **airlines**: Stores information about Canadian airlines
- **rights**: Contains details about passenger rights for specific scenarios by airline
- **users**: Manages user accounts (for future admin functionality)

## Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add some amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## License

Distributed under the MIT License. See `LICENSE` for more information.

## Acknowledgments

- [Canadian Transportation Agency](https://rppa-appr.ca/) for APPR regulations information
- [Drizzle ORM](https://github.com/drizzle-team/drizzle-orm) for the database ORM
- [Next.js](https://nextjs.org/) for the React framework
- [Tailwind CSS](https://tailwindcss.com/) for styling

## Contact

Project Link: [https://github.com/yourusername/airrights-canada](https://github.com/yourusername/airrights-canada)