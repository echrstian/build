// script to push database schema changes
const { exec } = require('child_process');
const fs = require('fs');
const path = require('path');
const { Pool } = require('pg');

// Create drizzle migration directory if it doesn't exist
const drizzleDir = path.join(__dirname, '../drizzle');
if (!fs.existsSync(drizzleDir)) {
  fs.mkdirSync(drizzleDir, { recursive: true });
}

// Create a direct SQL migration for the initial schema
console.log('Pushing database schema changes...');

// Connection to the database
const pool = new Pool({ connectionString: process.env.DATABASE_URL });

const createTablesSQL = `
-- Create airlines table
CREATE TABLE IF NOT EXISTS airlines (
  id SERIAL PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  iata_code VARCHAR(10),
  description TEXT,
  slug VARCHAR(100) NOT NULL UNIQUE,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

-- Create rights table
CREATE TABLE IF NOT EXISTS rights (
  id SERIAL PRIMARY KEY,
  airline_id INTEGER NOT NULL REFERENCES airlines(id),
  scenario_type VARCHAR(50) NOT NULL,
  compensation_amount TEXT,
  eligibility_criteria TEXT,
  legal_reference TEXT,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW(),
  UNIQUE(airline_id, scenario_type)
);

-- Create users table
CREATE TABLE IF NOT EXISTS users (
  id SERIAL PRIMARY KEY,
  username VARCHAR(50) NOT NULL UNIQUE,
  email VARCHAR(100) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);
`;

async function executeMigration() {
  const client = await pool.connect();
  try {
    await client.query(createTablesSQL);
    console.log('Database schema updated successfully!');
  } catch (err) {
    console.error('Error executing migration:', err);
  } finally {
    client.release();
    await pool.end();
  }
}

executeMigration();