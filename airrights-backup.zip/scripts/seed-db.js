// Database seeding script
const { Pool } = require('pg');
const { drizzle } = require('drizzle-orm/node-postgres');

// Import our schema directly from the ORM models
const pool = new Pool({ connectionString: process.env.DATABASE_URL });

// Sample data for airlines
const airlines = [
  {
    name: 'Air Canada',
    iata_code: 'AC',
    description: 'Canada\'s largest airline and flag carrier.',
    slug: 'air-canada'
  },
  {
    name: 'WestJet',
    iata_code: 'WS',
    description: 'Canada\'s second-largest airline.',
    slug: 'westjet'
  },
  {
    name: 'Porter Airlines',
    iata_code: 'PD',
    description: 'Regional airline headquartered at Billy Bishop Toronto City Airport.',
    slug: 'porter'
  },
  {
    name: 'Flair Airlines',
    iata_code: 'F8',
    description: 'Ultra-low-cost carrier based in Edmonton.',
    slug: 'flair'
  },
  {
    name: 'Lynx Air',
    iata_code: 'Y9',
    description: 'Canadian ultra-low-cost carrier.',
    slug: 'lynx'
  }
];

// Sample rights data
const rights = [
  // Air Canada
  {
    airline_slug: 'air-canada',
    scenario_type: 'delay',
    compensation_amount: '$400 CAD for delays between 3-6 hours, $700 CAD for delays between 6-9 hours, $1,000 CAD for delays 9+ hours',
    eligibility_criteria: 'Flight delay must be within airline control and not safety-related. Applies to flights departing or arriving in Canada.',
    legal_reference: 'Air Passenger Protection Regulations (APPR), SOR/2019-150'
  },
  {
    airline_slug: 'air-canada',
    scenario_type: 'cancellation',
    compensation_amount: '$400 CAD for cancellations within 3-6 hours of scheduled departure, $700 CAD for 6-9 hours, $1,000 CAD for 9+ hours',
    eligibility_criteria: 'Cancellation must be within airline control and not safety-related. Rebooking required.',
    legal_reference: 'Air Passenger Protection Regulations (APPR), SOR/2019-150'
  },
  {
    airline_slug: 'air-canada',
    scenario_type: 'denied-boarding',
    compensation_amount: '$900 CAD for 0-6 hours arrival delay, $1,800 CAD for 6-9 hours, $2,400 CAD for 9+ hours',
    eligibility_criteria: 'Applies to denied boarding due to overbooking or aircraft changes within carrier control.',
    legal_reference: 'Air Passenger Protection Regulations (APPR), SOR/2019-150'
  },
  {
    airline_slug: 'air-canada',
    scenario_type: 'baggage',
    compensation_amount: 'Up to $2,350 CAD for lost, damaged or delayed baggage',
    eligibility_criteria: 'Must file report within 7 days for damaged baggage, 21 days for delayed baggage.',
    legal_reference: 'Montreal Convention, Air Passenger Protection Regulations (APPR)'
  },
  {
    airline_slug: 'air-canada',
    scenario_type: 'refund',
    compensation_amount: 'Full refund plus $400-$1,000 CAD based on length of delay',
    eligibility_criteria: 'For controllable flight cancellations or delays over 3 hours if passenger chooses refund over rebooking.',
    legal_reference: 'Air Passenger Protection Regulations (APPR), SOR/2019-150'
  },
  
  // WestJet
  {
    airline_slug: 'westjet',
    scenario_type: 'delay',
    compensation_amount: '$400 CAD for delays between 3-6 hours, $700 CAD for delays between 6-9 hours, $1,000 CAD for delays 9+ hours',
    eligibility_criteria: 'Applies to delays within WestJet\'s control. Must be requested within 1 year.',
    legal_reference: 'Air Passenger Protection Regulations (APPR), SOR/2019-150'
  },
  {
    airline_slug: 'westjet',
    scenario_type: 'cancellation',
    compensation_amount: '$400 CAD for cancellations within 3-6 hours of original arrival, $700 CAD for 6-9 hours, $1,000 CAD for 9+ hours',
    eligibility_criteria: 'For cancellations within WestJet\'s control, not related to safety.',
    legal_reference: 'Air Passenger Protection Regulations (APPR), SOR/2019-150'
  }
];

// Function to seed airlines
async function seedAirlines(client) {
  console.log('Seeding airlines...');
  
  for (const airline of airlines) {
    await client.query(
      'INSERT INTO airlines (name, iata_code, description, slug) VALUES ($1, $2, $3, $4) ON CONFLICT (slug) DO NOTHING',
      [airline.name, airline.iata_code, airline.description, airline.slug]
    );
  }
  
  console.log('Airlines seeded successfully!');
}

// Function to seed rights
async function seedRights(client) {
  console.log('Seeding rights...');
  
  for (const right of rights) {
    // Get airline ID from slug
    const airlineResult = await client.query('SELECT id FROM airlines WHERE slug = $1', [right.airline_slug]);
    
    if (airlineResult.rows.length > 0) {
      const airlineId = airlineResult.rows[0].id;
      
      await client.query(
        'INSERT INTO rights (airline_id, scenario_type, compensation_amount, eligibility_criteria, legal_reference) VALUES ($1, $2, $3, $4, $5) ON CONFLICT (airline_id, scenario_type) DO UPDATE SET compensation_amount = $3, eligibility_criteria = $4, legal_reference = $5',
        [
          airlineId,
          right.scenario_type,
          right.compensation_amount,
          right.eligibility_criteria,
          right.legal_reference
        ]
      );
    }
  }
  
  console.log('Rights seeded successfully!');
}

// Main seed function
async function seedDatabase() {
  const client = await pool.connect();
  
  try {
    console.log('Starting database seeding...');
    
    await client.query('BEGIN');
    await seedAirlines(client);
    await seedRights(client);
    await client.query('COMMIT');
    
    console.log('Database seeded successfully!');
  } catch (error) {
    await client.query('ROLLBACK');
    console.error('Error seeding database:', error);
  } finally {
    client.release();
    await pool.end();
  }
}

// Run the seed function
seedDatabase();