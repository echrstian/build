// Airline type
export interface Airline {
  id: string;
  name: string;
  iata_code?: string;
  description?: string;
  slug: string;
}

// Scenario types
export type ScenarioType = 'delay' | 'cancellation' | 'denied-boarding' | 'baggage' | 'refund';

// Rights information type
export interface Right {
  id: string;
  airline_id: string;
  scenario_type: ScenarioType;
  compensation_amount?: string;
  eligibility_criteria?: string;
  legal_reference?: string;
}
