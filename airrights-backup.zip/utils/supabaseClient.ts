// This file is now just a placeholder with utility functions
// since we're migrating from Supabase to direct database access via API

// API utility functions for frontend
export const api = {
  // Fetch all airlines
  async getAllAirlines() {
    const response = await fetch('/api/airlines');
    
    if (!response.ok) {
      throw new Error('Failed to fetch airlines');
    }
    
    return await response.json();
  },
  
  // Fetch a specific airline by slug
  async getAirlineBySlug(slug: string) {
    const response = await fetch(`/api/airlines/${slug}`);
    
    if (!response.ok) {
      throw new Error('Failed to fetch airline');
    }
    
    return await response.json();
  },
  
  // Fetch all rights for an airline
  async getRightsByAirline(airlineId: number) {
    const response = await fetch(`/api/rights/by-airline/${airlineId}`);
    
    if (!response.ok) {
      throw new Error('Failed to fetch rights');
    }
    
    return await response.json();
  },
  
  // Fetch a specific right by airline and scenario
  async getRightsByScenario(airlineId: number, scenarioType: string) {
    try {
      const response = await fetch(`/api/rights/by-scenario/${airlineId}/${scenarioType}`);
      
      if (response.status === 404) {
        // Return null for 404 (not found) responses
        return null;
      }
      
      if (!response.ok) {
        throw new Error(`Failed to fetch right: ${response.status} ${response.statusText}`);
      }
      
      return await response.json();
    } catch (error) {
      console.error('Error in getRightsByScenario:', error);
      throw error;
    }
  }
};
