import { airlines, type Airline, type InsertAirline } from "../shared/schema";
import { rights, type Right, type InsertRight } from "../shared/schema";
import { users, type User, type InsertUser } from "../shared/schema";
import { db } from "./db";
import { eq, and } from "drizzle-orm";

// Interface for storage operations
export interface IStorage {
  // Airline operations
  getAirline(id: number): Promise<Airline | undefined>;
  getAirlineBySlug(slug: string): Promise<Airline | undefined>;
  getAllAirlines(): Promise<Airline[]>;
  createAirline(insertAirline: InsertAirline): Promise<Airline>;
  
  // Rights operations
  getRightsByAirline(airlineId: number): Promise<Right[]>;
  getRightsByScenario(airlineId: number, scenarioType: string): Promise<Right | undefined>;
  createRight(insertRight: InsertRight): Promise<Right>;
  
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(insertUser: InsertUser): Promise<User>;
}

// Database storage implementation 
export class DatabaseStorage implements IStorage {
  // Airline operations
  async getAirline(id: number): Promise<Airline | undefined> {
    const [airline] = await db.select().from(airlines).where(eq(airlines.id, id));
    return airline || undefined;
  }

  async getAirlineBySlug(slug: string): Promise<Airline | undefined> {
    const [airline] = await db.select().from(airlines).where(eq(airlines.slug, slug));
    return airline || undefined;
  }

  async getAllAirlines(): Promise<Airline[]> {
    return await db.select().from(airlines);
  }

  async createAirline(insertAirline: InsertAirline): Promise<Airline> {
    const [airline] = await db
      .insert(airlines)
      .values(insertAirline)
      .returning();
    return airline;
  }

  // Rights operations
  async getRightsByAirline(airlineId: number): Promise<Right[]> {
    return await db.select().from(rights).where(eq(rights.airline_id, airlineId));
  }

  async getRightsByScenario(airlineId: number, scenarioType: string): Promise<Right | undefined> {
    const [right] = await db
      .select()
      .from(rights)
      .where(and(
        eq(rights.airline_id, airlineId),
        eq(rights.scenario_type, scenarioType as any)
      ));
    return right || undefined;
  }

  async createRight(insertRight: InsertRight): Promise<Right> {
    const [right] = await db
      .insert(rights)
      .values(insertRight)
      .returning();
    return right;
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }
}

// Export the storage instance
export const storage = new DatabaseStorage();