import { pgTable, serial, text, varchar, timestamp, foreignKey, uniqueIndex } from 'drizzle-orm/pg-core';
import { relations } from 'drizzle-orm';

// Airlines table
export const airlines = pgTable('airlines', {
  id: serial('id').primaryKey(),
  name: varchar('name', { length: 100 }).notNull(),
  iata_code: varchar('iata_code', { length: 10 }),
  description: text('description'),
  slug: varchar('slug', { length: 100 }).notNull().unique(),
  created_at: timestamp('created_at').defaultNow(),
  updated_at: timestamp('updated_at').defaultNow()
});

// ScenarioType type for rights
export type ScenarioType = 'delay' | 'cancellation' | 'denied-boarding' | 'baggage' | 'refund';

// Rights table
export const rights = pgTable('rights', {
  id: serial('id').primaryKey(),
  airline_id: serial('airline_id').references(() => airlines.id).notNull(),
  scenario_type: varchar('scenario_type', { length: 50 }).notNull(),
  compensation_amount: text('compensation_amount'),
  eligibility_criteria: text('eligibility_criteria'),
  legal_reference: text('legal_reference'),
  created_at: timestamp('created_at').defaultNow(),
  updated_at: timestamp('updated_at').defaultNow()
}, (table) => {
  return {
    airline_scenario_unique: uniqueIndex('airline_scenario_unique').on(table.airline_id, table.scenario_type)
  };
});

// Users table
export const users = pgTable('users', {
  id: serial('id').primaryKey(),
  username: varchar('username', { length: 50 }).notNull().unique(),
  email: varchar('email', { length: 100 }).notNull().unique(),
  password_hash: varchar('password_hash', { length: 255 }).notNull(),
  created_at: timestamp('created_at').defaultNow(),
  updated_at: timestamp('updated_at').defaultNow()
});

// Define relationships between tables
export const airlinesRelations = relations(airlines, ({ many }) => ({
  rights: many(rights)
}));

export const rightsRelations = relations(rights, ({ one }) => ({
  airline: one(airlines, {
    fields: [rights.airline_id],
    references: [airlines.id]
  })
}));

// Export types for our schema
export type Airline = typeof airlines.$inferSelect;
export type InsertAirline = typeof airlines.$inferInsert;

export type Right = typeof rights.$inferSelect;
export type InsertRight = typeof rights.$inferInsert;

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;